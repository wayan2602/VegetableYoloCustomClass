# Food Rekomendation > 2023-05-11 4:16pm
https://universe.roboflow.com/i-wayan-adi-saputra-79v4k/food-rekomendation

Provided by a Roboflow user
License: CC BY 4.0

